antwoord1 = 22*1157
print(antwoord1)

antwoord2 = 3.40+2.45+1.95
antwoord3 = antwoord2/100*9
antwoord3 = round(antwoord3, 2)
print(antwoord3)