woord_1 = input("Wat voor soort dag moet het zijn? ")
stad_1 = input("Noem een stad: ")
naam_1 = input("Noem een naam: ")
woord_3 = input("Noem een object: ")
woord_4 = input("Beschrijf een man/vrouw: ")
woord_5 = input("Noem een nieuw object: ")
woord_6 = input("Noem iets dat je buiten kunt zien: ")
woord_7 = input("Noem een werkwoord: ")


print("Het was " + (woord_1) + " in " + (stad_1) + ". " + (naam_1) + " liep door de straten, op zoek naar een " + 
(woord_3) + ". Plotseling zie je een " + (woord_4) + " man/vrouw die een " + (woord_5) + " verkocht. " + (naam_1) +
" besloot om het te kopen en liep verder. Toen " +(naam_1) + " bij een " + (woord_6) + " kwam, zag hij/zij een groep mensen die " +
(woord_7) + ". " + (naam_1) + " besloot om mee te doen en had de tijd van zijn/haar leven." )
