dagSec = 60*60*24
weekSec = dagSec * 7
jaarSec = weekSec * 365


print('Seconden in een dag is: ', dagSec)
print('Seconden in een week is: ', weekSec)
print('Seconden in een jaar is:', jaarSec)