print( 5*2 -3+4/2 )
print( 5*2 - 3+4 / 2 )

print( (5*2) - (3+4) /2 )
print( ((5*2) -(3+4)) / 2 )

#pemdas is het antwoord voor allebei (voorrang rekenen)