naam = 'Dimitri'

print('Hallo ' + naam + ', ik leer nu programmeren.')

#gebruikte operators: +, werkt met een andere naam