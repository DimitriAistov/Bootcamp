naam = '252'

print('Hallo ' + naam + ', ik leer nu programmeren.')

#het is een integer die een string word gemaakt