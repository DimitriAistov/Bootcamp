variabele1 = 25
variabele2 = 0

uitkomst = variabele1 / variabele2
print (uitkomst)

#Het laat geen uitkomst zien omdat de uitkomst oneindig is (ZeroDivisionError)