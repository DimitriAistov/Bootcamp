#Ik denk gewoon het antwoord

print( (431 / 100) * 100 )

#Je krijgt het hele antwoord met kommagetal 

