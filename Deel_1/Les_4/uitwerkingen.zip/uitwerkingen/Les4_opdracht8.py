som1 = round(625 / 13)
som2 = 625 % 13


print(som1,'rest',som2)