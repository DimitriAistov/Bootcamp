#Collegegeld

Studenten = 28
Collegegeld = 1157
GeldKlas = Studenten * Collegegeld
print('Het collegegeld van de klas is: ',GeldKlas)
print('Hoeveelheid studenten', Studenten)
print('Collegegeld jaar 23/24', Collegegeld)



#Fruit
antwoord2 = 3.40+2.45+1.95
antwoord3 = antwoord2/100*9
antwoord3 = round(antwoord3, 2)
print('De BTW voor al het fruit in de fruitmand: ', antwoord3)
print('De btw op fruit is 9%')