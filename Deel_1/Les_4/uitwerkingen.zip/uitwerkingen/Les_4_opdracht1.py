print( 15+4 )   # 4 toevoegen aan 15
print( 15-4 )   # 4 afhalen van 15
print( 15*4 )   # 4 keer 15
print( 15/4 )   # hoevaak je iets kunt delen met rest
print( 15//4 )  # hoevaak je iets kunt delen zonder rest
print( 15**4 )  # 4 keer 15 maar exponentieel (machtsverheffen)
print( 15%4 )   # 4 delen door 15 en het antwoord is rest
