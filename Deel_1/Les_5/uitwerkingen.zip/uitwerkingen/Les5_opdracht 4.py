import math

straal = int(input('Wat is de straal van de cirkel? '))


print(straal * straal * math.pi)