nummer1 = int(input('voer eerste getal in ' ))
nummer2 = int(input('voer tweede getal in ' ))
nummer3 = int(input('voer derde getal in ' ))

gemiddelde = (nummer1 + nummer2 + nummer3)/3
print (gemiddelde)