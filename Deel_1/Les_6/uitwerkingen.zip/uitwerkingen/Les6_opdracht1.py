if x = 18:
        print('de waarde van x = 18')

#Wat er niet klopt is dat de X waarde nog niet is aangegeven maar wel wordt gebruikt in een if
#er moet ook een tweede '=' bij de if x =18 ->  if x == 18