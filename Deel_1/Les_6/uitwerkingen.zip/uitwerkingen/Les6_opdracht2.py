varA = input('Wat is het eerste getal? ')
varB = input('Wat is het tweede getal? ')


if varA > varB:
    print('Variabele a is het grootst want ', varA, 'is groter dan', varB)
if varB > varA:
    print('Variabele b is het grootst want ', varB, 'is groter dan', varA)
if varA == varB:
    print('Variabele a en b zijn gelijk.')