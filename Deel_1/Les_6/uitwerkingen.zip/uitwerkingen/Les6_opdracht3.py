Leeftijd = int(input('Wat is U leeftijd? '))

if Leeftijd >= 16:
    print('Gefeliciteerd, je mag je brommerrijbewijs halen.')
if Leeftijd < 16:
    print('Helaas, je zult nog even moeten wachten.')
