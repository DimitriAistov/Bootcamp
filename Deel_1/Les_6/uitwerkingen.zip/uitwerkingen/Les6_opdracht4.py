a=3
b=5
c=7
d=12
e=2
f=22

print(a<b)
print(c>d)
print(e<f)
print(a>d)
print(b==c)