for A in range(1,26):
    print(A)