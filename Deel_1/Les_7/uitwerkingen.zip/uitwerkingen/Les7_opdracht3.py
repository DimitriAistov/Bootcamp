nummer1 = 625
nummer2 = 25
nummer3 = 0
while(nummer1 - nummer2 >= 0):
    nummer1 -= nummer2
    nummer3 += 1
print (nummer3)