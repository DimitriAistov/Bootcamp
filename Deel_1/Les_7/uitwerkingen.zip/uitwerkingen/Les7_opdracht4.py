nummer1 = 625
nummer2 = 12
nummer3 = 0
while(nummer1 - nummer2 >= 0):
    nummer1 -= nummer2
    nummer3 += 1
print (nummer3)

#Niks extra hoeft aangepast te worden naast de cijfers