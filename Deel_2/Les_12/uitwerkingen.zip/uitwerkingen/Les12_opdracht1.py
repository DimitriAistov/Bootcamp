leeftijd = int(input('Wat is uw leeftijd? '))

LeeftijdLater = leeftijd + 5

print('Uw leeftijd over 5 jaar is: ', LeeftijdLater)