getal1 = float(input('Voer een getal in '))
getal2 = float(input('Voer nog een getal in '))

uitkomst = (getal1 + getal2) /2

print(uitkomst)