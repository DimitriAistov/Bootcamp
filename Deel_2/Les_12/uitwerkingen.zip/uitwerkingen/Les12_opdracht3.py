woord = input('Voer een woord in ')
letters = len(woord)


print('Het woord is: ',woord, ' en bestaat uit ', letters, ' tekens')