lijst = []


lijst.append(int(input('Noem een getal dat U wilt toevoegen aan de lijst. ')))
for x in range(4):
    lijst.append(int(input('Noem nog een getal dat U wilt toevoegen. ')))


print (lijst)