def functie1(A=10, B=5):
    print(A * B)

functie1()